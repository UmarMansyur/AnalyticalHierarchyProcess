<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Beranda</h4>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <img src="./assets/img/undraw_convert_re_l0y1.svg" alt="animasi" class="img-fluid d-block">
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos officia totam voluptatem quis enim. Omnis eaque eos corrupti. Eos neque laborum quaerat atque animi dolor commodi itaque quia voluptates ipsa?
            </div>
        </div>
    </div>
</div>