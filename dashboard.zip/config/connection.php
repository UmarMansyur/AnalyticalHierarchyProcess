<?php
$conn = new mysqli('localhost:3306', 'root', '', 'db_ahp');
